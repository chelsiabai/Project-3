//Subclass of Student
public class Student_Employee extends Student
{
	String job;
	String jobT;
	String fName;
	String lName;
	String level;
	String active;
	Boolean check;
	int iD;
	
	// Constructor
	public Student_Employee(String fName, String lName, String level, Boolean check, int iD, String job, String jobT)
	{
		super(fName, lName, level, check, iD, job, jobT);
		this.fName = fName;
        this.lName = lName;
        this.level = level;
        this.check = check;
        this.iD = iD;
        this.job = job;
        this.jobT = jobT;
	}

	// Displays everyone with a job
	public void displayJob()
	{
		
		System.out.println("\n" +  fName + " " + lName + "\n" +  "ID: " + iD + "\n" + jobT + " " + job);
	}
	
	// Returns the job position
	public String returnJ()
	{
		return job;
	}
	
	
}