import java.io.File;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;


public class Course implements CMS
{
	int courseID;
	String courseN;
	File file = new File("CourseAssignment.txt");
	
	// Constructor
	public Course()
	{
		
	}
	public void display()
	{
		String line = null;
		try {
			// A stream that connects to the text file
			FileReader fileReader = new FileReader(file); 
			// Connect the FileReader to the BufferedReader
			BufferedReader bufferedReader = new BufferedReader(fileReader); 

			// Display the file's contents on the screen, one line at a time
			while((line = bufferedReader.readLine()) != null) 
			{
				System.out.println(line); 
			}
			
			// Close the stream
			bufferedReader.close(); 
		} catch (IOException e) {
			System.out.println("No CourseAssignment.txt file found.");
			e.printStackTrace();
		}
		
	}
	
}
