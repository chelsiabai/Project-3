//This project creates a Student Management System
import java.util.*;
import java.io.IOException;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Files;
import java.io.FileWriter;


// SMS interface
interface  SMS
{
    public void printArray();
    public void checkID(int dID);
    public void findID(int fID);
    public String returnF();
    public String returnL();
    public int returnID();
    public String returnLev();

}

// CMS interface
interface CMS
{
	public void display();
}

public class ChelsiaBaidar_Section002_Project2
{
	// Throws exception
    public static void main(String[] args) throws IOException
    {       
    		// Sets the value of check to true and allows the while loop to run
            Boolean check = true;
            // Sets value of i to 0 and increments, so that they are not able to add more users pass the limit
            int i = 0;
            int iD; 
            Scanner sc = new Scanner(System.in);
            
            //This displays the introduction of the Student and Course Management System 
            
            System.out.println("\tWelcome to the Student and Course Management System!");
            System.out.print("\nThis system will allow you to manage students and courses."
                             + " Let's start with the number of student this system will have: ");
            int length =  sc.nextInt();
            
            // Creates the object arrays
            Student[] arr = new Student[length]; 
            Student_Employee[] stu = new Student_Employee[length];
			Boolean[] arr3 = new Boolean[length];
			
			// Displays menu options for Student and Course Management Systems
            while(check  == true)
            { 
            	
            	//Asks the user to select an option between 0-4
                System.out.println("\n***Welcome to Student and Course Management System***\n");
                System.out.println("Press '1' for Student Management System (SMS)");
                System.out.println("Press '2' for Course Management System (CMS)");
                System.out.println("Press '0' to exit\n");
                
                
                int option = sc.nextInt();
                
                // Chooses a menu option for Student and Course Management Systems
                switch(option)
                { 
                	// SMS
                    case  1:
                    {   
                    	Boolean checker = true;
                    	
                    	// Displays SMS menu options
                    	while(checker)
                    	{
                    		System.out.println("***Welcome to SMS***\n");
                    		System.out.println("Press '1' to add student");
                    		System.out.println("Press '2' to deactivate a student");
                    		System.out.println("Press '3' to display all students");
                    		System.out.println("Press '4' to search for a student by ID");
                    		System.out.println("Press '5' to assign on-campus job");
                    		System.out.println("Press '6' to display all students with on-campus jobs");
                    		System.out.println("Press '0' to exit SMS.\n");
                    		int choice = sc.nextInt();
                    		
                    		// Choose a SMS menu option
                    		switch(choice)
                    		{
                    			// Adds a student to database 
                    			case 1:
                    			{
                    				//If the i is greater than 0, displays an error message
                                    if (i >= length)
                                    {
                                            System.out.println("Error, max number of students has been reached");
                                            break;
                                    }
                                    //Asks the user to input the first name
                                    System.out.print("Enter first name: ");
                                    sc.nextLine();
                                    String fName = sc.nextLine();
                                    
                                    //Asks the user to input the last name
                                    System.out.print("Enter last name: ");
                                    String lName = sc.nextLine();
                                    
                                    //Asks the user to input the level of the student
                                    System.out.print("Enter level of the student: ");
                                    String level = sc.nextLine();
                                     
                                    //Chooses an ID number between 0 - 99
                                    iD = new Random().nextInt(99 + 1);
                                    arr[i] = new Student(fName, lName, level, check, iD, "null", "null");
                                    stu[i] = new Student_Employee(fName, lName, level, check, iD, "null", "null");
                 
                                    //Displays students full name, level and ID
                                    System.out.println("\n" + fName + " " + lName + " has been addded as a " + level + " with ID " +iD + "\n");
                                    arr3[i] = false;
                                    i++;
                    				break;
                    			}
                    			
                    			// Choose a student ID to deactivate
                    			case 2:
                    			{
                    				System.out.print("Enter the ID for the student that you want to deactivate: ");
                                    int dID = sc.nextInt();
                                    
                                    for(int k = 0; k < i; k++)
                                    {
                                        arr[k].checkID(dID);
                                    }
                                    break;
                    			}
                    			
                    			// Displays all the students
                    			case 3:
                    			{
                    				//Orders the array alphabetically by first name if there is more than one student
                                    if(i > 1)
                                    {
                                    	//Orders the array alphabetically by first name and moves it into the array 
                                        for(int j = 0; j < i; j++)
                                        {
                                            for(int m = j + 1; m < i; m++)
                                            {
                                                String first = arr[j].returnF();
                                                String second = arr[m].returnF();
                                                if(first.compareTo(second) > 0)
                                                {
                                                    Student temp = arr[j]; 
                                                    arr[j] = arr[m];
                                                    arr[m] = temp;
                                                }
                                            }
                                        }
                                    }
                                    for(int j = 0; j < i; j++)
                                    {
                                    arr[j].printArray();
                                    }
                                    break;
                    			}
                    			
                    			// Searches for student based on student ID
                    			case 4:
                    			{
                    				System.out.print("Enter student ID: ");
                                    int fID = sc.nextInt();
                                    for(int l = 0; l < i; l++)
                                    {
                                        arr[l].findID(fID);
                                    } 
                                    break;
                    				
                    			}
                    			
                    			// Assigns a job position and job type to student.
                    			case 5:
                    			{
                    				System.out.print("Enter student ID: ");
                    				int studentID = sc.nextInt();
                    				System.out.print("\nEnter job: ");
                    				sc.nextLine();
                    				String job = sc.nextLine();
                    				System.out.print("\nEnter job type: ");
                    				String jobT = sc.nextLine();
                    				for(int j = 0; j < i; j++)
                    				{
                    					if(studentID == (arr[j].returnID()))
                    					{
                    					System.out.println(arr[j].returnF() + " " + arr[j].returnL() + " has been assigned " + jobT + " " + job + "job");
                    					stu[j] = new Student_Employee(arr[j].returnF(), arr[j].returnL(), arr[j].returnLev(), check, arr[j].returnID(), job, jobT);
                    					arr3[j] = true;
                    					}
                    				}	
                    				
                    				break;
                    			}
                    			
                    			// Displays all the students that have a job
                    			case 6:
                    			{
                    				for(int y = 0; y < i ; y++)
                                    {
                    					if(arr3[y] == true)
                    					{	
                    						stu[y].displayJob();
                    					}
                                    }
                    				break;
                    			}
                    			
                    			// Exits out of the SMS
                    			case 0:
                    			{
                    				checker = false;
                                    break;
                    			}
                    			default:
                    			{
                    				System.out.println("Error, please try again");
                    			}
                    			
                    		}
                    	}
                        break;
                        
                    }
                    
                    // CMS
                    case 2:
                    {	
                    	// Displays CMS menu options
                        Boolean checking = true;
                    	while(checking)
                    	{
                    		System.out.println("\n***Welcome to CMS***\n");
                    		System.out.println("Press '1' to add a new course");
                    		System.out.println("Press '2' to assign a student to a new course");
                    		System.out.println("Press '3' to display students with assigned courses");
                    		System.out.println("Press '0' to exit CMS\n");
                    		int ch = sc.nextInt();
                    		
                    		// Chooses a CMS menu option
                    		switch(ch)
                    		{	
                    			// User enters course ID and name. Then, the program writes it to a file 
                        		case 1:
                        		{
                        			System.out.print("Enter course ID: ");
                        			int courseID = sc.nextInt();
                        			System.out.print("Enter course name: ");
                        			sc.nextLine();
                        			String courseN = sc.nextLine();	
                        			File file = new File("Courses.txt");
                        			
                        			// Try and catch block
                        			try
                        			{           				
                        				// Checks to see if the file exists 
                        				if(!file.exists())
                        				{
                        					// Creates a new file if it does not exists
                        					file.createNewFile();
                        				}
                        				else
                        				{
                        					System.out.println("File already exists");
                        					
                        				}
                        				// A stream that connects to the text file
                        				FileWriter writer = new FileWriter(file, true);
                        				// Writes the course information into a text file and displays a message confirming the course
                    			    	writer.write("Course ID: " + courseID + "\n" + "Course Name: " + courseN + "\n");
                    			    	System.out.println("Confirmation: New Course " + courseID + " has been added");
                    			    	// Closes the stream
                    			    	writer.close();
                        			}catch (IOException e)
                        			{
                        				e.printStackTrace();
                        			}
                        			break;
                        			
                        		}
                        		
                        		// User enters student ID and courseID. Then, the program assigns the student and writes it to a file
                        		case 2:
                        		{
                        			System.out.println("Enter student ID: ");
                        			int stuID = sc.nextInt();
                        			System.out.println("Enter course ID: ");
                        			int cID = sc.nextInt();
                        			File F = new File("CourseAssignment.txt");
                        			
                        			// Try and catch block 
                        			try {
                        				
                        				// Checks to see if the file exists
                        				if(!F.exists())
                        				{
                        					// Creates new file if it odes not exist
                        					F.createNewFile();
                        				}
                        				else
                        				{
                        					System.out.println("File already exists");
                        					
                        				}
                        				// A stream that connects to the text file
                        				FileWriter w = new FileWriter(F, true);
                        				
                        				// Loops through all the students in the database
                    					for(int x = 0; x < i; x++)
                    					{
                    						// Writes to text file and displays a message if the student ID entered is the same as one in the database
                    						if(stuID == arr[x].returnID())
                    						{
                    							System.out.println("Confirmation: " + arr[x].returnF() + " " + arr[x].returnL() + " has been assigned course " + cID);
                    							w.write(arr[x].returnF() + " " + arr[x].returnL() + "\n");
                    							w.write("ID: " + stuID + "\n");
                    							w.write("Courses: " + cID + "\n\n" );
                    							// Closes the Stream
                    							w.close();
                    							
                    						}					
                    					}
                    					
                    					
                    					
                        			}catch (Exception e) {
                        				e.printStackTrace();
                        			}
                        			break;
                        		}	
                        		
                        		// Displays all the contents of a file
                        		case 3:
                        		{
                        			Course c = new Course();
                        			c.display();
                        			
                        		}
                        		
                        		// Exits out of CMS
                        		case 0:
                        		{
                        			checking = false;
                                    break;
                        		}
                        		default:
                        		{
                        		System.out.println("Error, please try again");
                        		}
                    		}
                    	} 
                        break;
                    }
                    
                    // Exits out out of the entire program
                    case 0:
                    {
                        check = false;
                        break;
                    }
                    default:
                    {
                        System.out.println("Error, please try again");
                    }
               }
                
            }
            
            // Displays the system has been exited 
            System.out.println("Good Bye!!!\n");
            return;
    }

}

