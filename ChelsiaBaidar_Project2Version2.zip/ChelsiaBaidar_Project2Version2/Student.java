public class Student implements SMS
{
	// Displays the variables 
    String fName;
    String lName;
    String level;
    String active;
    Boolean check;
    int iD;
    String job;
	String jobT;
    
    // Puts the student information in the object array 
    public Student(String fName, String lName, String level, Boolean check, int iD, String job, String jobT)
    {
        this.fName = fName;
        this.lName = lName;
        this.level = level;
        this.check = check;
        this.iD = iD;
        this.job = job;
        this.jobT = jobT;
    }
    
    // Prints the array
    public void printArray()
    {
    	//Checks if the value is true 
        if(check == true)
        {
            active = "Active";
        }
        
        //Otherwise the value is inactive
        else
        {
            active = "Inactive";
        }
        
        //Displays the student full name, ID, level and active
        System.out.println("\n" +  fName + " " + lName + "\n" +  "ID: " + iD + "\nLevel: " + level + "\nStatus: " + active);
    }
    
    // Prints the array 
    public void checkID(int dID)
    {
    	//Checks if the value is equivalent to the ID
        if(dID == iD)
        {
            check = false;
            System.out.println("\n" + fName + " " + lName + " has been deactivated");
        }
    }
    
    // Prints the array
    public void findID(int fID)
    {
        if(fID == iD)
        {
            System.out.println("\n" + fName + " " + lName + "\n" +  "ID: " + iD + "\nLevel: " + level + "\nStatus: " + active);
        }

    }
    
    // Returns the first name
    public String returnF()
    {
        return fName;
    }
    
    // Returns the last name
    public String returnL()
    {
        return lName;
    }
    
    // Returns the ID
    public int returnID()
    {
        return iD;
    }
    
    // Returns the level
    public String returnLev()
    {
        return level;
    }
    
}

